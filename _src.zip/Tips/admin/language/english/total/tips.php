<?php
$_['heading_title']    = 'Tips Fee';
$_['text_total']       = 'Order Totals';
$_['text_success']     = 'Success: You have modified tips fee total!';
$_['entry_total']      = 'Order Total:';
$_['entry_fee']        = 'Fee:';
$_['entry_tax_class']  = 'Tax Class:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Sort Order:';
$_['error_permission'] = 'Warning: You do not have permission to modify Tips fee total!';
?>