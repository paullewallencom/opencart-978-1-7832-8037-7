<?php
$_['text_tips'] = 'Thanking you !!!';
?>