<?php
// Text
$_['text_title']  = 'Total Cost Based Shipping';
$_['text_Total Cost'] = 'Total Cost:'; 
?>