<?php
// Heading
$_['heading_title'] = 'Feedback';
$_['viewall'] = 'View All';
?>