<?php
// Text
$_['text_feedback']     = 'List of feedback';
$_['text_description']  = 'List of feedback';
$_['text_keywords']  = 'List of feedback';
$_['text_error']        = 'Feedback not found!';
$_['text_empty']        = 'There are no feedbacks to list.';

?>